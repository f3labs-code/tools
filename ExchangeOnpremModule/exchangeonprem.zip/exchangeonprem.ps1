# Create object to export
$export_object = @()

# Get Exchange Servers
$exchange_servers = Get-ExchangeServer | select Name
$exchange_servers = $exchange_servers | Out-String
$export_object += [pscustomobject]@{label="Exchange Servers";content=$exchange_servers}

#Get Exchange Server Versions
$exchange_serverversion = Get-ExchangeServer | select Name, AdminDisplayVersion
$exchange_serverversion = $exchange_serverversion | Out-String
$export_object += [pscustomobject]@{label="Exchange Server Versions";content=$exchange_serverversion}

# Get Exchange Server Operating Systems
$exchange_serveros = Get-ExchangeServer | select Name | foreach {get-adcomputer $_.name -Properties *} | select DNSHostname, OperatingSystem
$exchange_serveros = $exchange_serveros | out-String
$export_object += [pscustomobject]@{label="Exchange Server OS Versions";content=$exchange_serveros}

# Get Total Number of Exchange Servers
$exchange_servercount = ($exchange_servers).count
$exchange_servercount = $exchange_servercount | Out-String
$export_object += [pscustomobject]@{label="Exchange Server Count";content=$exchange_servercount}

# Get Exchange Server Roles
$exchange_serverroles = Get-ExchangeServer | select Name,ServerRole
$exchange_serverroles = $exchange_serverroles | Out-String
$export_object += [pscustomobject]@{label="Exchange Server Roles";content=$exchange_serverroles}

# Get Exchange Server Enterprise Edition
$exchange_enterprise = Get-ExchangeServer | select Name,Edition | where {$_.Edition -eq "Enterprise"}
$exchange_enterprise = $exchange_enterprise | Out-String
$export_object += [pscustomobject]@{label="Exchange Server Enterprise";content=$exchange_enterprise}

# Get Exchange Server Standard Edition
$exchange_standard = Get-ExchangeServer | select Name,Edition | where {$_.Edition -eq "Standard"}
$exchange_standard = $exchange_standard | Out-String
$export_object += [pscustomobject]@{label="Exchange Server Enterprise";content=$exchange_standard}

# Get DAG List
$dag_list = Get-DatabaseAvailabilityGroup
$dag_list = $dag_list | Out-String
$export_object += [pscustomobject]@{label="Database Availability Groups";content=$dag_list}

# Get DAG Witness
$dag_witness = Get-DatabaseAvailabilityGroup | select Name, WitnessServer
$dag_witnes = $dag_witnes | Out-String
$export_object += [pscustomobject]@{label="Database Availability Group Witness Servers";content=$dag_witness}

# Get DAG IP Addresses
$dag_ips = Get-DatabaseAvailabilityGroup | select Name, DatabaseAvailabilityGroupIpv4Addresses
$dag_ips = $dag_ips | Out-String
$export_object += [pscustomobject]@{label="Database Availability Group IPs";content=$dag_ips}


# Get users in admin roles
$admin_roles = Get-RoleGroupMember "Organization Management"
$admin_roles = $admin_roles | out-string
$export_object += [pscustomobject]@{label="Administrators";content=$admin_roles}

# Get Journal Rules
$journal_rules = Get-JournalRule
$journal_rules = $journal_rules | out-string
$export_object += [pscustomobject]@{label="Journal Rules";content=$journal_rules}

# Get Federation Trusts
$fed_trusts = Get-FederationTrust
$fed_trusts = $fed_trusts | Out-String
$export_object += [pscustomobject]@{label="Federation Trusts";content=$fed_trusts}

# Get Org Relationships
$org_relationship = Get-OrganizationRelationship
$org_relationship = $org_relationship | Out-String
$export_object += [pscustomobject]@{label="Org Relationships";content=$org_relationships}

# Outlook Anywhere General
$outlook_anywhere = Get-OutlookAnywhere
$oa_enabled = $outlook_anywhere | where {$_.IsValid -eq "True"} | select Hostname
$oa_external = $outlook_anywhere | select-object Hostname,ExternalHostname
$oa_internal = $outlook_anywhere | select-object Hostname,InternalHostname
$oa_auth = $outlook_anywhere | select-object Hostname,IISAuthenticationMethods
$oa_enabled = $oa_enabled | Out-String
$oa_external = $oa_external | Out-String
$oa_internal = $oa_internal | Out-String
$oa_auth = $oa_auth | Out-String

$export_object += [pscustomobject]@{label="Outlook Anywhere Enabled Servers";content=$oa_enabled}
$export_object += [pscustomobject]@{label="Outlook Anywhere External URL";content=$oa_external}
$export_object += [pscustomobject]@{label="Outlook Anywhere Internal URL";content=$oa_internal}
$export_object += [pscustomobject]@{label="Outlook Anywhere Auth Methods";content=$oa_auth}

# Get Mailbox Databases
$mailbox_db = Get-MailboxDatabase | select Name,Server
$mailbox_db = $mailbox_db | Out-String
$export_object += [pscustomobject]@{label="Mailbox DBs";content=$mailbox_db}

# Get Public Folder Databases
$pf_db = Get-PublicFolderDatabase | Select Name,Server
$pf_db = $pf_db | Out-String
$export_object += [pscustomobject]@{label="Public Folder DBs";content=$pf_db}

# Get Archiving Enabled
$archiving = Get-Mailbox -Filter "ArchiveGuid -ne `$null"
if (($archiving).count -eq 0) {
    $export_object += [pscustomobject]@{label="Archiving Enabled";content="Yes"}
} else {
    $export_object += [pscustomobject]@{label="Archiving Enabled";content="No"}
}

# Get Journaling Enabled
$journaling = Get-MailboxDatabase | select Name,JournalRecipient
$journaling = $journaling | Out-String
$export_object += [pscustomobject]@{label="Journaling Enabled";content=$journaling}

# Get Outlook Web Access Mailbox Policies
$owa_mailboxpolicies = Get-OwaMailboxPolicy | select Name
$owa_mailboxpolicies = $owa_mailboxpolicies | Out-String
$export_object += [pscustomobject]@{label="OWA Mailbox Policies";content=$owa_mailboxpolicies}

# Get Edge Subscriptions
$edge_subscriptions = Get-EdgeSubscription
$edge_subscriptions = $edge_subscriptions | Out-String
$export_object += [pscustomobject]@{label="Edge Subscriptions";content=$edge_subscriptions}

# Get Unified Messaging
$um = Get-UMMailbox
$um = $um | Out-String
$export_object += [pscustomobject]@{label="Unified Messaging ";content=$um}

# Get Exchange Certificates
$exch_certs = Get-ExchangeCertificate | select CertificateDomains, Services, NotAfter
$exch_certs = $exch_certs | Out-String
$export_object += [pscustomobject]@{label="Exchange Certs";content=$exch_certs}

# Get Receive Connectors
$rec_connector = Get-Receiveconnector | select Server,Name
$rec_connector = $rec_connector| Out-String
$export_object += [pscustomobject]@{label="Receive Connectors";content=$rec_connector}




# Get Total Mailboxes
$user_mailboxes = Get-Mailbox -Resultsize Unlimited -RecipientTypeDetails "UserMailbox"
$shared_mailboxes = Get-Mailbox -Resultsize Unlimited -RecipientTypeDetails "SharedMailbox"
$room_mailboxes = Get-Mailbox -Resultsize Unlimited -RecipientTypeDetails "RoomMailbox"
$equip_mailboxes = Get-Mailbox -Resultsize Unlimited -RecipientTypeDetails "EquipmentMailbox"
$content = "User Mailboxes: " + $user_mailboxes.count + "`nShared Mailboxes: " + $shared_mailboxes.count + "`nRoom Mailboxes: " + $room_mailboxes.count + "`nEquipment Mailboxes: " + $equip_mailboxes.count

$export_object += [pscustomobject]@{label="Mailbox Count";content=$content}

# Check for Archive Mailboxes
$archive_mailboxes = Get-Mailbox -ResultSize Unlimited | where {$_.ArchiveStatus -eq "Active"}
$archive_mailboxes = $archive_mailboxes | Out-String
$export_object += [pscustomobject]@{label="Archive Mailboxes";content=$archive_mailboxes}

# Check for Sharing Policy
$sharing_policy = Get-sharingpolicy
$sharing_policy = $sharing_policy | Out-String
$export_object += [pscustomobject]@{label="Sharing Policies";content=$sharing_policy}

# Get Address Lists
$address_lists = Get-AddressList
$address_lists = $address_lists | out-string
$export_object += [pscustomobject]@{label="Address Lists";content=$address_lists}

# Get Retention Policies
$retention_policies = Get-RetentionPolicy
$retention_policies = $retention_policies | out-string
$export_object += [pscustomobject]@{label="Retention Policies";content=$retention_policies}

# Get offline address books
$offline_addressbooks = Get-OfflineAddressBook 
$offline_addressbooks = $offline_addressbooks | Out-String
$export_object += [pscustomobject]@{label="Offline Address Books";content=$offline_addressbooks}

# Get oab policies
$oab_policies = Get-AddressBookPolicy
$oab_policies = $oab_policies | Out-String
$export_object += [pscustomobject]@{label="OAB Policies";content=$oab_policies}

# Get ActiveSync Policies
$activesync_policies = Get-ActiveSyncMailboxPolicy
$activesync_policies = $activesync_policies | Out-String
$export_object += [pscustomobject]@{label="Activesync Policies";content=$activesync_policies}

# Get Remote Domains
$remote_domains = Get-RemoteDomain 
$remote_domains = $remote_domains | out-string
$export_object += [pscustomobject]@{label="Remote Domains";content=$remote_domains}

# Get Accepted Domains
$accepted_domains = Get-AcceptedDomain


# Get MX Records
$mxrecords = @()
foreach($domain in $accepted_domains) {
    
        $mxrecords += & nslookup -type=mx $domain.domainname

}

$mxrecords = $mxrecords | Out-String
$export_object += [pscustomobject]@{label="MX Records";content=$mxrecords}

# Get TXT Records
$spfrecords = @()
foreach($domain in $accepted_domains) {
 
        $spfrecords += & nslookup -type=txt $domain.domainName

}

$spfrecords = $spfrecords | Out-String
$export_object += [pscustomobject]@{label="SPF Records";content=$spfrecords}

$accepted_domains = $accepted_domains | out-string
$export_object += [pscustomobject]@{label="Accepted Domains";content=$accepted_domains}




# Get Email Address Policies
$email_address_policies = Get-EmailAddressPolicy
$email_address_policies = $email_address_policies | Out-String
$export_object += [pscustomobject]@{label="Email Address Policies";content=$email_address_policies}

# Get Transport Rules
$transport_rules = Get-TransportRule 
$transport_rules = $transport_rules | out-string
$export_object += [pscustomobject]@{label="Transport Rules";content=$transport_rules}

# Get Send Connectors
$send_connectors = Get-SendConnector
$send_connectors = $send_connectors | out-string
$export_object += [pscustomobject]@{label="Send Connectors";content=$send_connectors}

# Get Transport Settings
$transport_config = Get-transportconfig 
$max_receivesize = $transport_config.MaxReceiveSize 
$max_sendsize = $transport_config.MaxSendSize
$max_recipientenvelopelimit = $transport_config.MaxRecipientEnvelopeLimit 
$max_dumpster = $transport_config.MaxDumpsterSizePerDatabase
$max_dumpstertime = $transport_config.MaxDumpsterTime 

$content = "Max Receive Size: $max_receivesize `nMax Send Size: $max_sendsize `nMax Recipient Envelope Limit: $max_recipientenvelopelimit `nMax Dumpster Size: $max_dumpster `nMax Dumpster Time: $max_dumpstertime"
$export_object += [pscustomobject]@{label="Transport Settings";content=$content}

# Create Object to send to Export-CSV
$export_object | export-csv ".\onpremexchange_settings.csv" -NoTypeInformation
